package com.kdp.java;

public class HelloWorld {

	/**
	 * @author Kshitij Pawar	
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Greeting obj = new Greeting();
		System.out.println(obj.greet("Jenkins"));
	}	
}
