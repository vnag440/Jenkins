package com.kdp.java;

/**
 * @author Kshitij Pawar	
 * @param args
 */
public class Greeting {

	public String greet(String name){
		return "Helloooooo "+ name + "###";
	}

}
